module.exports = {
  name: "cmd6",
  description: "Command 6",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 6" });
  }
};