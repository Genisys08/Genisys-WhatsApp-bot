module.exports = {
  name: "cmd11",
  description: "Command 11",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 11" });
  }
};