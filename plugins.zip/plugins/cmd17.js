module.exports = {
  name: "cmd17",
  description: "Command 17",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 17" });
  }
};