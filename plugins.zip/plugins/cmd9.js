module.exports = {
  name: "cmd9",
  description: "Command 9",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 9" });
  }
};