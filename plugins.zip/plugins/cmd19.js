module.exports = {
  name: "cmd19",
  description: "Command 19",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 19" });
  }
};