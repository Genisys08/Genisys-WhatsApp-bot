module.exports = {
  name: "cmd4",
  description: "Command 4",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 4" });
  }
};