module.exports = {
  name: "cmd14",
  description: "Command 14",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 14" });
  }
};