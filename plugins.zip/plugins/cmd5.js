module.exports = {
  name: "cmd5",
  description: "Command 5",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 5" });
  }
};