module.exports = {
  name: "cmd2",
  description: "Command 2",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 2" });
  }
};