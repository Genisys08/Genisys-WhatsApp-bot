module.exports = {
  name: "cmd8",
  description: "Command 8",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 8" });
  }
};