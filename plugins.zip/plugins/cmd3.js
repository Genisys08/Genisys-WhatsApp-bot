module.exports = {
  name: "cmd3",
  description: "Command 3",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 3" });
  }
};