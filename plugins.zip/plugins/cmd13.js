module.exports = {
  name: "cmd13",
  description: "Command 13",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 13" });
  }
};