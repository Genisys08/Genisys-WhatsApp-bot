module.exports = {
  name: "cmd10",
  description: "Command 10",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 10" });
  }
};