module.exports = {
  name: "cmd12",
  description: "Command 12",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 12" });
  }
};