module.exports = {
  name: "cmd16",
  description: "Command 16",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 16" });
  }
};