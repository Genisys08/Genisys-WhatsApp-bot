module.exports = {
  name: "cmd20",
  description: "Command 20",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 20" });
  }
};