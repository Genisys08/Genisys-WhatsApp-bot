module.exports = {
  name: "cmd18",
  description: "Command 18",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 18" });
  }
};