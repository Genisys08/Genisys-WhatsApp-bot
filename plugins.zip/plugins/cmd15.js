module.exports = {
  name: "cmd15",
  description: "Command 15",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 15" });
  }
};