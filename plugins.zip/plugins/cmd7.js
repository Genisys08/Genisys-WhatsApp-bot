module.exports = {
  name: "cmd7",
  description: "Command 7",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 7" });
  }
};