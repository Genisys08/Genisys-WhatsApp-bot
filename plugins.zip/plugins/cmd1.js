module.exports = {
  name: "cmd1",
  description: "Command 1",
  run: async (sock, msg, args) => {
    await sock.sendMessage(msg.key.remoteJid, { text: "This is command 1" });
  }
};